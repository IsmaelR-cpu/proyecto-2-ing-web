<?php 
$titulo = "Registro"; // Título para el header.php
include ROOT_PATH . "/app/views/partials/header.php"; 
?>

<section class="masthead">
    <div class="container px-5">
        <div class="row gx-5 align-items-center">
            <div class="col-lg-12">
                <div class="p-5">
                    <h2 class="display-4 text-center">¡Crea tu Cuenta!</h2>
                    
                    <?php if (isset($registro_ok) && $registro_ok): ?>
                        <p class="text-success text-center">¡Registro exitoso! Por favor, inicia sesión.</p>
                    <?php endif; ?>

                    <form action="/proyecto_cursos_mvc/public/registrar.php" method="POST" class="mt-4">
                        <div class="mb-3">
                            <label class="form-label">Nombre</label>
                            <input type="text" name="nombre" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Contraseña</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-xl rounded-pill w-100">Registrarse</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
include ROOT_PATH . "/app/views/partials/footer.php"; 
?>