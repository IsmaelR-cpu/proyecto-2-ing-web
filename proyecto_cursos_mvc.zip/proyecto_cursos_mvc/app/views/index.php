<?php 
$titulo = "Inicio - Ingeniería Web";
include ROOT_PATH . "/app/views/partials/header.php"; 
?>

<header class="masthead text-center text-white">
    <div class="masthead-content">
        <div class="container px-5">
            <h1 class="masthead-heading mb-0">La Próxima Generación</h1>
            <h2 class="masthead-subheading mb-0">De Desarrolladores Web</h2>
            <a class="btn btn-primary btn-xl rounded-pill mt-5" href="/proyecto_cursos_mvc/public/explore.php">¡Ver Cursos!</a>
        </div>
    </div>
    <div class="bg-circle-1 bg-circle"></div>
    <div class="bg-circle-2 bg-circle"></div>
    <div class="bg-circle-3 bg-circle"></div>
    <div class="bg-circle-4 bg-circle"></div>
</header>

<section id="scroll">
    <div class="container px-5">
        <div class="row gx-5 align-items-center">
            <div class="col-lg-6 order-lg-2">
                <div class="p-5"><img class="img-fluid rounded-circle" src="/proyecto_cursos_mvc/public/assets/img/01.jpg" alt="Aprende a Crear" /></div>
            </div>
            <div class="col-lg-6 order-lg-1">
                <div class="p-5">
                    <h2 class="display-4">Aprende a Crear, No Solo a Usar</h2>
                    <p>Nuestro curso se enfoca en los fundamentos de la ingeniería de software aplicada al desarrollo web, dándote las herramientas para diseñar y construir aplicaciones robustas desde cero.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container px-5">
        <div class="row gx-5 align-items-center">
            <div class="col-lg-6">
                <div class="p-5"><img class="img-fluid rounded-circle" src="/proyecto_cursos_mvc/public/assets/img/02.jpg" alt="Full-Stack" /></div>
            </div>
            <div class="col-lg-6">
                <div class="p-5">
                    <h2 class="display-4">Maestría en Back-end y Front-end</h2>
                    <p>Desde la manipulación del DOM con JavaScript hasta la creación de APIs seguras con Node.js, cubrimos todo el stack para que te conviertas en un desarrollador Full-Stack.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container px-5">
        <div class="row gx-5 align-items-center">
            <div class="col-lg-6 order-lg-2">
                <div class="p-5"><img class="img-fluid rounded-circle" src="/proyecto_cursos_mvc/public/assets/img/03.jpg" alt="Inscripción" /></div>
            </div>
            <div class="col-lg-6 order-lg-1">
                <div class="p-5">
                    <h2 class="display-4">¡Inscríbete ahora!</h2>
                    <p>No esperes más para dar el primer paso hacia una carrera exitosa en la Ingeniería Web. Únete a nuestro curso y comienza tu viaje hoy mismo. Inscripciones abiertas, plazas limitadas. ¡Construye el futuro digital con nosotros!</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
include ROOT_PATH . "/app/views/partials/footer.php"; 
?>