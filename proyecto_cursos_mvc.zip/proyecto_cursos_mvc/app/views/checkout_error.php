<section class="masthead text-center">
    <div class="container px-5">
        <h1 class="display-4 mb-4 text-danger">Error al Procesar el Pago 🛑</h1>
        <div class="card p-5 shadow">
            <p class="lead"><?= htmlspecialchars($error_message) ?></p>
            <a href="/proyecto_cursos_mvc/public/carrito.php" class="btn btn-secondary mt-4">Volver al Carrito</a>
        </div>
    </div>
</section>