<?php 
$titulo = "Mi Carrito de Compras";
include ROOT_PATH . "/app/views/partials/header.php"; 
?>

<section class="masthead">
    <div class="container px-5">
        <h1 class="display-4 text-center mb-5">Mi Carrito de Compras</h1>
        
        <?php if (!empty($error_db)): ?>
            <p class="text-danger text-center"><?= htmlspecialchars($error_db) ?></p>
        <?php elseif (empty($items_carrito)): ?>
            <div class="alert alert-info text-center" role="alert">
                Tu carrito está vacío. ¡Explora nuestros <a href="/proyecto_cursos_mvc/public/explore.php">cursos</a>!
            </div>
        <?php else: ?>
            
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th scope="col">Curso</th>
                            <th scope="col" class="text-center">Precio Unitario</th>
                            <th scope="col" class="text-center">Cantidad</th>
                            <th scope="col" class="text-end">Subtotal</th>
                            <th scope="col" class="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items_carrito as $item): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="/proyecto_cursos_mvc/public/assets/img/<?= htmlspecialchars($item['imagen'] ?? 'default.jpg') ?>" class="img-thumbnail me-3" style="width: 60px; height: 60px;" alt="<?= htmlspecialchars($item['titulo']) ?>">
                                        <a href="/proyecto_cursos_mvc/public/detalles.php?id=<?= $item['curso_id'] ?>" class="text-decoration-none text-dark">
                                            <?= htmlspecialchars($item['titulo']) ?>
                                        </a>
                                    </div>
                                </td>
                                <td class="text-center">$<?= number_format($item['precio'], 2) ?></td>
                                <td class="text-center"><?= htmlspecialchars($item['cantidad']) ?></td>
                                <td class="text-end fw-bold">$<?= number_format($item['precio'] * $item['cantidad'], 2) ?></td>
                                <td class="text-center">
                                    <form method="POST" action="/proyecto_cursos_mvc/public/carrito_remove.php" class="d-inline">
                                        <input type="hidden" name="curso_id" value="<?= $item['curso_id'] ?>">
                                        <button type="submit" class="btn btn-danger btn-sm" title="Eliminar">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-end fw-bold fs-5">Total a Pagar:</td>
                            <td colspan="2" class="text-end fw-bold fs-5 text-primary">$<?= number_format($total_carrito, 2) ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <div class="d-flex justify-content-between mt-4">
                <a href="/proyecto_cursos_mvc/public/explore.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-2"></i>Seguir Comprando</a>
                <a href="/proyecto_cursos_mvc/public/checkout.php" class="btn btn-success btn-xl rounded-pill"><i class="fas fa-credit-card me-2"></i>Proceder al Pago</a>
            </div>

        <?php endif; ?>
    </div>
</section>

<?php 
include ROOT_PATH . "/app/views/partials/footer.php"; 
?>