<section class="masthead text-center">
    <div class="container px-5">
        <h1 class="display-4 mb-4 text-success">¡Pago y Pedido Procesado con Éxito! </h1>
        <div class="card p-5 shadow">
            <p class="lead">Tu pedido **#<?= htmlspecialchars($pedido_id) ?>** por un total de **$<?= number_format($total_pedido, 2) ?>** ha sido creado y pagado.</p>
            <p class="text-muted">El carrito de compras ha sido vaciado y el historial de tu compra está guardado.</p>
            <a href="/proyecto_cursos_mvc/public/explore.php" class="btn btn-primary btn-xl rounded-pill mt-4">Volver a Explorar Cursos</a>
        </div>
    </div>
</section>