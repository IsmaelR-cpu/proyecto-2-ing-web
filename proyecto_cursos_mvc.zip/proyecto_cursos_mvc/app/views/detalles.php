<?php 
// 🛑 CORRECCIÓN: Usamos 'titulo'
$titulo = ($curso) ? htmlspecialchars($curso['titulo']) : "Detalles del Curso";
include ROOT_PATH . "/app/views/partials/header.php"; 
?>

<section class="masthead">
    <div class="container px-5">
        <?php if ($error_message): ?>
            <h1 class="display-4 text-center text-danger"><?= htmlspecialchars($error_message) ?></h1>
            <p class="text-center"><a href="/proyecto_cursos_mvc/public/explore.php" class="btn btn-secondary mt-4">Volver a Explorar</a></p>
        <?php elseif ($curso): ?>
            <div class="row gx-5 align-items-start">
                <div class="col-lg-5">
                    <div class="p-3"><img class="img-fluid rounded shadow" src="/proyecto_cursos_mvc/public/assets/img/<?= htmlspecialchars($curso['imagen'] ?? 'default.jpg') ?>" alt="<?= htmlspecialchars($curso['titulo']) ?>" /></div>
                </div>
                <div class="col-lg-7">
                    <div class="p-3">
                        <h1 class="display-4"><?= htmlspecialchars($curso['titulo']) ?></h1>
                        <p class="lead fw-bold text-primary">$<?= number_format($curso['precio'], 2) ?></p>
                        
                        <h3 class="mt-4">Descripción</h3>
                        <p><?= htmlspecialchars($curso['descripcion']) ?></p>

                        <h3 class="mt-4">Contenido del Curso</h3>
                        <div class="mb-4">
                            <p><?= nl2br(htmlspecialchars($curso['descripcion'])) ?></p>
                        </div>

                        <form method="POST" action="/proyecto_cursos_mvc/public/carrito_add.php">
                            <input type="hidden" name="curso_id" value="<?= $curso['id'] ?>">
                            <button type="submit" class="btn btn-primary btn-xl rounded-pill">Añadir al Carrito</button>
                        </form>

                        <a href="/proyecto_cursos_mvc/public/explore.php" class="btn btn-secondary mt-3">Volver a Explorar</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php 
include ROOT_PATH . "/app/views/partials/footer.php"; 
?>