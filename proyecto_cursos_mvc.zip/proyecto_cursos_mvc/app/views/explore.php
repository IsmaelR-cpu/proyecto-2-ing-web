<?php 
$titulo = "Explorar Cursos";
include ROOT_PATH . "/app/views/partials/header.php"; 
?>

<section class="masthead">
    <div class="container px-5">
        <h1 class="display-4 text-center mb-5">Explora Nuestro Catálogo de Cursos</h1>
        
        <?php if (!empty($error_message)): ?>
            <p class="text-danger text-center"><?= $error_message ?></p>
        <?php elseif (empty($cursos)): ?>
            <p class="text-center">No hay cursos disponibles en este momento.</p>
        <?php else: ?>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <?php foreach ($cursos as $curso): ?>
                    <div class="col">
                        <div class="card h-100 shadow">
                            <img class="card-img-top" src="/proyecto_cursos_mvc/public/assets/img/<?= htmlspecialchars($curso['imagen'] ?? 'default.jpg') ?>" alt="<?= htmlspecialchars($curso['titulo']) ?>">
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title"><?= htmlspecialchars($curso['titulo']) ?></h5>
                                <p class="card-text flex-grow-1"><?= htmlspecialchars(substr($curso['descripcion'], 0, 100)) . '...' ?></p>
                                <p class="card-text fw-bold mt-2">$<?= number_format($curso['precio'], 2) ?></p>
                                
                                <a href="/proyecto_cursos_mvc/public/detalles.php?id=<?= $curso['id'] ?>" class="btn btn-primary mt-auto">Ver Detalles</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php 
include ROOT_PATH . "/app/views/partials/footer.php"; 
?>