<section class="masthead">
    <div class="container px-5">
        <h1 class="display-4 text-center mb-5">Finalizar Compra</h1>
        
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow p-4">
                    <h3 class="card-title text-center mb-4">Monto a Pagar: <span class="text-primary">$<?= number_format($total_pedido, 2) ?></span></h3>
                    
                    <form method="POST" action="/proyecto_cursos_mvc/public/checkout.php">
                        <input type="hidden" name="pay_submitted" value="1">
                        
                        <div class="mb-3">
                            <label for="card_number" class="form-label">Número de Tarjeta</label>
                            <input type="text" class="form-control" id="card_number" name="card_number" placeholder="XXXX XXXX XXXX XXXX" required maxlength="16" pattern="[0-9]{16}">
                        </div>
                        
                        <div class="mb-3">
                            <label for="card_name" class="form-label">Nombre del Titular</label>
                            <input type="text" class="form-control" id="card_name" name="card_name" required>
                        </div>
                        
                        <div class="row mb-4">
                            <div class="col-md-6 mb-3 mb-md-0">
                                <label for="expiry" class="form-label">Fecha de Vencimiento (MM/AA)</label>
                                <input type="text" class="form-control" id="expiry" name="expiry" placeholder="MM/AA" required maxlength="5" pattern="(0[1-9]|1[0-2])\/[0-9]{2}">
                            </div>
                            <div class="col-md-6">
                                <label for="cvv" class="form-label">CVV</label>
                                <input type="text" class="form-control" id="cvv" name="cvv" placeholder="123" required maxlength="4" pattern="[0-9]{3,4}">
                            </div>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-success btn-lg">Pagar Ahora $<?= number_format($total_pedido, 2) ?></button>
                            <a href="/proyecto_cursos_mvc/public/carrito.php" class="btn btn-outline-secondary">Volver al Carrito</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>