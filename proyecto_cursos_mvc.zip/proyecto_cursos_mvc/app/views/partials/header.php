<?php 
// ----------------------------------------------------
// LÓGICA DE SESIÓN Y CARRITO
// ----------------------------------------------------
$titulo = $titulo ?? "Ingeniería Web - Curso";
$usuario_logueado = $_SESSION['nombre_usuario'] ?? null;
$item_count = 0;

if (isset($_SESSION['usuario_id'])) {
    // Si está logueado, cuenta ítems en la tabla 'carrito'
    
    // FIX: Se corrige la ruta de require_once a una ruta relativa segura
    if (!isset($db)) {
        // La ruta correcta desde views/partials/ a app/config/database.php es ../../config/database.php
        // Usamos __DIR__ para un cálculo de ruta más robusto
        require_once __DIR__ . "/../../config/database.php"; 
        $db = new Database();
    }
    $conn = $db->getConnection();
    
    if ($conn) {
        // Sumar la cantidad de todos los ítems del usuario
        $query_count = "SELECT SUM(cantidad) AS total FROM carrito WHERE usuario_id = ?";
        $stmt_count = $conn->prepare($query_count);
        $stmt_count->execute([$_SESSION['usuario_id']]);
        $result = $stmt_count->fetch(PDO::FETCH_ASSOC);
        $item_count = (int)($result['total'] ?? 0);
    }
} elseif (isset($_COOKIE['carrito'])) {
    // Si no está logueado, cuenta ítems en la cookie
    $carrito_cookie = json_decode($_COOKIE['carrito'], true);
    if (is_array($carrito_cookie)) {
        // Sumar las cantidades de todos los cursos en el array
        $item_count = array_sum($carrito_cookie);
    }
}

// Si $item_count es mayor a 99, lo limitamos para el badge
$display_count = $item_count > 99 ? '99+' : $item_count;

// ----------------------------------------------------
// COMIENZA EL HTML
// ----------------------------------------------------
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="Curso de Ingeniería Web" />
        <meta name="author" content="Curso de Ingeniería Web" />
        <title><?= htmlspecialchars($titulo) ?></title>
        <link rel="icon" type="image/x-icon" href="/proyecto_cursos_mvc/public/assets/favicon.ico" />
        
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet" />
        
        <link href="/proyecto_cursos_mvc/public/css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
            <div class="container px-5">
                <a class="navbar-brand" href="/proyecto_cursos_mvc/public/index.php">Ingeniería Web</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link" href="/proyecto_cursos_mvc/public/index.php">Inicio</a></li>
                        <li class="nav-item"><a class="nav-link" href="/proyecto_cursos_mvc/public/explore.php">Explorar</a></li>
                        
                        <?php if ($usuario_logueado): ?>
                            <li class="nav-item"><a class="nav-link text-warning fw-bold" href="/proyecto_cursos_mvc/public/mis_cursos.php">Mis Cursos</a></li>
                        <?php endif; ?>

                        <li class="nav-item">
                            <a class="nav-link position-relative" href="/proyecto_cursos_mvc/public/carrito.php">
                                <i class="fas fa-shopping-cart me-1"></i> Carrito
                                <?php if ($item_count > 0): ?>
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                        <?= $display_count ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </li>
                        
                        <?php if ($usuario_logueado): ?>
                            <li class="nav-item"><span class="nav-link text-warning fw-bold">Hola, <?= htmlspecialchars($usuario_logueado) ?></span></li>
                            <li class="nav-item"><a class="btn btn-outline-light rounded-pill ms-lg-2" href="/proyecto_cursos_mvc/public/logout.php">Salir</a></li>
                        <?php else: ?>
                            <li class="nav-item"><a class="nav-link" href="/proyecto_cursos_mvc/public/registrar.php">Registro</a></li>
                            <li class="nav-item"><a class="btn btn-primary rounded-pill ms-lg-2" href="/proyecto_cursos_mvc/public/login.php">Iniciar Sesión</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <section>
            <div class="container px-5">