<footer style="text-align:center; padding: 20px; margin-top: 30px;">
    <p>© <?= date('Y'); ?> - Proyecto Cursos MVC</p>
</footer>
</body>
</html>
