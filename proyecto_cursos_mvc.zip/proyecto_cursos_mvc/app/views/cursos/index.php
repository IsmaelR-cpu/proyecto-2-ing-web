<h1>Cursos disponibles</h1>
<div class="cursos">
    <?php foreach ($cursos as $curso): ?>
        <div class="curso">
            <h3><?= $curso['titulo']; ?></h3>
            <p><?= $curso['descripcion']; ?></p>
            <strong>$<?= $curso['precio']; ?></strong>
            <br><br>
            <a href="/proyecto_cursos_mvc/public/carrito.php?curso_id=<?= $curso['id']; ?>" class="btn btn-success">Agregar al carrito</a>
        </div>
    <?php endforeach; ?>
</div>
