<?php
$cursos = $resultado->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="/proyecto_cursos_mvc/public/css/cursos.css">

<h1>Cursos Disponibles</h1>

<div class="contenedor-cursos">
<?php foreach ($cursos as $curso): ?>
    <div class="card">
        <img src="/proyecto_cursos_mvc/public/img/<?php echo $curso['imagen']; ?>" alt="Curso">

        <h3><?php echo $curso['nombre']; ?></h3>
        <p class="precio">$<?php echo $curso['precio']; ?></p>
        <p class="categoria"><?php echo $curso['categoria']; ?> —
        <?php echo $curso['nivel']; ?></p>

        <?php if(isset($_SESSION['usuario_id'])): ?>
            <button class="btn">Agregar al carrito</button>
        <?php else: ?>
            <small>Inicia sesión para comprar</small>
        <?php endif; ?>
    </div>
<?php endforeach; ?>
</div>
