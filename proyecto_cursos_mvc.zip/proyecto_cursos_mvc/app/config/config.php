<?php
define('ROOT_PATH', dirname(__DIR__, 1)); 
