<?php

// 1. CORRECCIÓN DE LA RUTA: Usamos ROOT_PATH (definida en index.php) para apuntar directamente al modelo.
require_once(ROOT_PATH . '/app/models/Usuario.php'); 
// Asumiendo que Usuario.php usa Database.php, Database.php debe usar ROOT_PATH internamente.

class AuthController {

    public function mostrarRegistro() {
        // Corrección de la ruta: De controllers a views
        include '../views/auth/registro.php';
    }

    public function mostrarLogin() {
        // Corrección de la ruta: De controllers a views
        include '../views/auth/login.php';
    }

    public function registrar() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $usuario = new Usuario();
            if ($usuario->registrar($_POST['nombre'], $_POST['email'], $_POST['password'])) {
                header("Location: /proyecto_cursos_mvc/public/?login");
                exit();
            } else {
                echo "❌ Error al registrar usuario";
            }
        }
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $usuario = new Usuario();
            $resultado = $usuario->login($_POST['email']);
            $data = $resultado->fetch(PDO::FETCH_ASSOC);

            if ($data && password_verify($_POST['password'], $data['password'])) {
                $_SESSION['usuario_id'] = $data['id'];
                $_SESSION['usuario_nombre'] = $data['nombre'];
                header("Location: /proyecto_cursos_mvc/public/");
                exit();
            } else {
                echo "❌ Credenciales incorrectas";
            }
        }
    }

    public function logout() {
        session_destroy();
        header("Location: /proyecto_cursos_mvc/public/");
    }
}