<?php
require_once ROOT_PATH . '/models/Curso.php';

class CursoController {

    public function listar() {
        $curso = new Curso();
        $cursos = $curso->obtenerCursos();

        require ROOT_PATH . '/views/partials/header.php';
        require ROOT_PATH . '/views/cursos/index.php';
        require ROOT_PATH . '/views/partials/footer.php';
    }
}
