<?php
require_once "../app/models/Curso.php";

class CursosController {

    public function index() {
        $curso = new Curso();
        $result = $curso->obtenerCursos();

        $cursos = $result->fetchAll(PDO::FETCH_ASSOC);

        include "../app/views/cursos/index.php";
    }
}
