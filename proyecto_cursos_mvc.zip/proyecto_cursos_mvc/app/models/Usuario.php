<?php
require_once ROOT_PATH . '/config/database.php';

class Usuario {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function registrar($nombre, $email, $password) {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $query = $this->conn->prepare("INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)");
        return $query->execute([$nombre, $email, $password_hash]);
    }

    public function login($email) {
        $query = $this->conn->prepare("SELECT * FROM usuarios WHERE email = ?");
        $query->execute([$email]);
        return $query;
    }
}
