<?php

require_once ROOT_PATH . '/config/database.php';



class Curso {
    private $conn;
    private $table = "cursos";

    public function __construct() {
        
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function obtenerCursos() {
        
        if ($this->conn === null) {
            
            error_log("Error: La conexión a la base de datos no está disponible en Curso.php");
            return false; 
        }
        
        $query = "SELECT * FROM " . $this->table;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Obtiene un curso específico por su ID.
     * Utiliza consultas preparadas para prevenir inyección SQL.
     *
     * @param int $id El ID del curso a buscar.
     * @return PDOStatement|false Retorna el objeto PDOStatement con el resultado, o false si falla.
     */
    public function obtenerCursoPorId($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        // Vincula el parámetro :id para la consulta preparada
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        return $stmt;
    }
}