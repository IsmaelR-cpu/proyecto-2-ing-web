<?php
session_start();

require_once __DIR__ . '/../app/config/config.php';
require_once ROOT_PATH . '/models/Curso.php';

$db = new Database();
$conn = $db->getConnection();
$cursoModel = new Curso($conn);

$carrito = [];

if (isset($_SESSION['usuario_id'])) {
    $stmt = $conn->prepare("SELECT curso_id, cantidad FROM carrito WHERE usuario_id = ?");
    $stmt->execute([$_SESSION['usuario_id']]);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $carrito[$row['curso_id']] = $row['cantidad'];
    }
} else {
    $carrito = isset($_COOKIE['carrito']) ? json_decode($_COOKIE['carrito'], true) : [];
}

$total = 0;

require ROOT_PATH . '/views/partials/header.php';

echo "<h1>Carrito 🛒</h1>";

if (empty($carrito)) {
    echo "<p>El carrito está vacío 😢</p>";
    echo "<a href='index.php'>Seguir comprando</a>";
    require ROOT_PATH . '/views/partials/footer.php';
    exit();
}

echo "<table border='1' cellpadding='10'>";
echo "<tr><th>Curso</th><th>Precio</th><th>Cantidad</th><th>Subtotal</th><th></th></tr>";

foreach ($carrito as $curso_id => $cantidad) {
    $stmt = $cursoModel->obtenerCursoPorId($curso_id);
    $curso = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($curso) {
        $subtotal = $curso['precio'] * $cantidad;
        $total += $subtotal;

        echo "<tr>
            <td>{$curso['titulo']}</td>
            <td>\${$curso['precio']}</td>
            <td>{$cantidad}</td>
            <td>\${$subtotal}</td>
            <td><a href='eliminar_carrito.php?id={$curso_id}'>Eliminar</a></td>
        </tr>";
    }
}

echo "<tr><td colspan='3'><strong>Total:</strong></td><td><strong>\${$total}</strong></td><td></td></tr>";
echo "</table>";

echo "<br><a href='index.php'>Seguir comprando</a>";

require ROOT_PATH . '/views/partials/footer.php';
