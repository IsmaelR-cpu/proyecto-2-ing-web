<?php
// Mantenemos el reporte de errores
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Define la ruta raíz del proyecto (es C:\xampp\htdocs\proyecto_cursos_mvc)
define('ROOT_PATH', dirname(__DIR__));
session_start();
require_once ROOT_PATH . "/app/config/database.php";

// Si la solicitud es POST (el usuario envió el formulario)
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nombre = $_POST["nombre"];
    $email = $_POST["email"];
    
    // Hashing de contraseña
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    $db = new Database();
    $conn = $db->getConnection();

    if ($conn === null) {
        echo "ERROR FATAL: Falló la conexión a la base de datos."; 
        exit(); 
    }

    $query = "INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);

    if ($stmt->execute([$nombre, $email, $password])) {
        // Redirección FINAL CORREGIDA
        header("Location: /proyecto_cursos_mvc/public/login.php?registro=ok");
        exit();
    } else {
        // Muestra el error de la DB
        echo "Error al registrar usuario: " . $stmt->errorInfo()[2];
    }

} else {
    // 🛑 SOLUCIÓN AL FALLO EN BLANCO: Si la solicitud es GET, incluimos el HTML del formulario.
    include ROOT_PATH . "/app/views/auth/registro.php";
}
?>