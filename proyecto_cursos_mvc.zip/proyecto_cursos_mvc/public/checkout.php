<?php
// Reporte de errores
ini_set('display_errors', 1);
error_reporting(E_ALL);

define('ROOT_PATH', dirname(__DIR__));
session_start();
require_once ROOT_PATH . "/app/config/database.php";

$db = new Database();
$conn = $db->getConnection();
$error_message = "";
$pedido_creado = false;
$total_pedido = 0;
$pedido_id = null;

// 1. Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php?redirect=checkout");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];

// 2. Lógica para PROCESAR EL PAGO (Guardar en DB)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['pay_submitted'])) {
    
    // Asumimos que la validación de tarjeta fue exitosa para la simulación
    
    if ($conn) {
        // Obtener los ítems del carrito para calcular el total
        $query_carrito = "SELECT c.curso_id, c.cantidad, t.precio 
                          FROM carrito c 
                          JOIN cursos t ON c.curso_id = t.id 
                          WHERE c.usuario_id = ?";
        $stmt_carrito = $conn->prepare($query_carrito);
        $stmt_carrito->execute([$usuario_id]);
        $items_carrito = $stmt_carrito->fetchAll(PDO::FETCH_ASSOC);

        if (empty($items_carrito)) {
            $error_message = "Tu carrito está vacío. No se puede proceder al pago.";
        } else {
            // Iniciar Transacción
            $conn->beginTransaction();
            try {
                // A. Calcular el total y crear el registro en la tabla 'pedidos'
                foreach ($items_carrito as $item) {
                    $total_pedido += $item['precio'] * $item['cantidad'];
                }
                
                // Insertar el pedido (Corregido: sin columna 'estado')
                $query_pedido = "INSERT INTO pedidos (usuario_id, total) VALUES (?, ?)";
                $stmt_pedido = $conn->prepare($query_pedido);
                $stmt_pedido->execute([$usuario_id, $total_pedido]);
                $pedido_id = $conn->lastInsertId();

                // B. Insertar detalles en 'pedido_detalle'
                $query_detalle = "INSERT INTO pedido_detalle (pedido_id, curso_id, cantidad, precio) VALUES (?, ?, ?, ?)";
                $stmt_detalle = $conn->prepare($query_detalle);

                foreach ($items_carrito as $item) {
                    $stmt_detalle->execute([
                        $pedido_id, 
                        $item['curso_id'], 
                        $item['cantidad'], 
                        $item['precio'] 
                    ]);
                }

                // C. Vaciar el carrito
                $query_vaciar = "DELETE FROM carrito WHERE usuario_id = ?";
                $stmt_vaciar = $conn->prepare($query_vaciar);
                $stmt_vaciar->execute([$usuario_id]);

                $conn->commit();
                $pedido_creado = true;
                
            } catch (Exception $e) {
                $conn->rollBack();
                $error_message = "Error interno al procesar el pago. Detalle: " . $e->getMessage();
            }
        }
    } else {
        $error_message = "Error de conexión a la base de datos.";
    }
} else {
    // Si no es POST, calcular el total solo para mostrarlo en el formulario
    if ($conn) {
        $query_total = "SELECT SUM(c.cantidad * t.precio) AS total 
                        FROM carrito c 
                        JOIN cursos t ON c.curso_id = t.id 
                        WHERE c.usuario_id = ?";
        $stmt_total = $conn->prepare($query_total);
        $stmt_total->execute([$usuario_id]);
        $result = $stmt_total->fetch(PDO::FETCH_ASSOC);
        $total_pedido = (float)($result['total'] ?? 0);

        if ($total_pedido == 0) {
             $error_message = "Tu carrito está vacío. No se puede proceder al pago.";
        }
    }
}

$titulo = "Procesar Pago";
include ROOT_PATH . "/app/views/partials/header.php";

// 3. Mostrar la vista: Formulario, Confirmación o Error
if ($pedido_creado) {
    // Si el pago se procesó, muestra la confirmación
    include ROOT_PATH . "/app/views/checkout_confirm.php";
} elseif ($total_pedido > 0 && empty($error_message)) {
    // Si hay ítems y no hay error, muestra el formulario de tarjeta
    include ROOT_PATH . "/app/views/checkout_form.php";
} else {
    // Muestra el mensaje de error (carrito vacío o error de DB)
    include ROOT_PATH . "/app/views/checkout_error.php";
}

include ROOT_PATH . "/app/views/partials/footer.php";
?>