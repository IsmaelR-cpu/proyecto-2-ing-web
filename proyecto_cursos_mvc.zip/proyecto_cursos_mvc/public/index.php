<?php
// Reporte de errores y configuración de sesión
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('ROOT_PATH', dirname(__DIR__));
session_start();
// Aunque el inicio sea estático, mantenemos la inclusión para consistencia
require_once ROOT_PATH . "/app/config/database.php"; 

// Incluimos la vista de index
include ROOT_PATH . "/app/views/index.php";
?>