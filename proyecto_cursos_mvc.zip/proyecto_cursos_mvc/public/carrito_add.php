<?php
// Reporte de errores y configuración de sesión
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('ROOT_PATH', dirname(__DIR__));
session_start();
require_once ROOT_PATH . "/app/config/database.php";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['curso_id'])) {
    
    $curso_id = filter_var($_POST['curso_id'], FILTER_VALIDATE_INT);
    if ($curso_id === false || $curso_id <= 0) {
        header("Location: explore.php?error=ID_invalido");
        exit();
    }
    
    $cantidad = 1; // Asumimos que siempre se añade 1 curso a la vez

    // 1. Lógica para USUARIOS LOGUEADOS (Base de Datos)
    if (isset($_SESSION['usuario_id'])) {
        $usuario_id = $_SESSION['usuario_id'];
        $db = new Database();
        $conn = $db->getConnection();

        if ($conn) {
            // Verificar si el curso ya existe en el carrito del usuario
            $query_check = "SELECT cantidad FROM carrito WHERE usuario_id = ? AND curso_id = ?";
            $stmt_check = $conn->prepare($query_check);
            $stmt_check->execute([$usuario_id, $curso_id]);

            if ($stmt_check->rowCount() > 0) {
                // Actualizar la cantidad (incrementar en 1)
                $query_update = "UPDATE carrito SET cantidad = cantidad + ? WHERE usuario_id = ? AND curso_id = ?";
                $stmt_update = $conn->prepare($query_update);
                $stmt_update->execute([$cantidad, $usuario_id, $curso_id]);
            } else {
                // Insertar nuevo curso en el carrito
                $query_insert = "INSERT INTO carrito (usuario_id, curso_id, cantidad) VALUES (?, ?, ?)";
                $stmt_insert = $conn->prepare($query_insert);
                $stmt_insert->execute([$usuario_id, $curso_id, $cantidad]);
            }
        }
    } 
    // 2. Lógica para VISITANTES (Cookie)
    else {
        // Obtener el carrito de la cookie o iniciar uno vacío
        $carrito = isset($_COOKIE['carrito']) ? json_decode($_COOKIE['carrito'], true) : [];

        if (isset($carrito[$curso_id])) {
            $carrito[$curso_id] += $cantidad;
        } else {
            $carrito[$curso_id] = $cantidad;
        }

        // Guardar el carrito actualizado en la cookie por 1 día (86400 segundos)
        setcookie('carrito', json_encode($carrito), time() + (86400 * 1), "/");
    }

    // Redirigir a la página de detalles del curso con un mensaje de éxito
    header("Location: detalles.php?id=$curso_id&added=true");
    exit();
} 

// Redirigir si se accede directamente o sin ID
header("Location: explore.php");
exit();
?>