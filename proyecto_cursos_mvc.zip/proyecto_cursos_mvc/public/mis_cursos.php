<?php
// Reporte de errores
ini_set('display_errors', 1);
error_reporting(E_ALL);

define('ROOT_PATH', dirname(__DIR__));
session_start();
require_once ROOT_PATH . "/app/config/database.php";

$db = new Database();
$conn = $db->getConnection();
$mis_cursos = [];
$error_message = "";

// 1. Redirigir si no está logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];

if ($conn) {
    try {
        // 2. Consulta para obtener todos los cursos que el usuario ha comprado.
        // Se unen: pedido_detalle (para saber el curso), pedidos (para saber si el pedido es del usuario) y cursos (para obtener los detalles).
        $query = "
            SELECT DISTINCT
                c.id, 
                c.titulo, 
                c.descripcion, 
                c.imagen
            FROM 
                cursos c
            JOIN 
                pedido_detalle pd ON c.id = pd.curso_id
            JOIN 
                pedidos p ON pd.pedido_id = p.id
            WHERE 
                p.usuario_id = ?
            ORDER BY 
                c.titulo ASC
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$usuario_id]);
        $mis_cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Exception $e) {
        $error_message = "Error al cargar tus cursos: " . $e->getMessage();
    }
} else {
    $error_message = "Error de conexión a la base de datos.";
}

$titulo = "Mis Cursos";
include ROOT_PATH . "/app/views/partials/header.php";
?>

<section class="masthead">
    <div class="container px-5">
        <h1 class="display-4 text-center mb-5">Mis Cursos Comprados 📚</h1>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger text-center"><?= htmlspecialchars($error_message) ?></div>
        <?php endif; ?>

        <?php if (empty($mis_cursos)): ?>
            <div class="alert alert-info text-center p-4 shadow">
                <h3 class="mb-3">¡Aún no has comprado ningún curso!</h3>
                <p class="lead">Explora nuestro catálogo y comienza tu viaje de aprendizaje hoy.</p>
                <a href="/proyecto_cursos_mvc/public/explore.php" class="btn btn-primary btn-lg mt-3">Explorar Cursos</a>
            </div>
        <?php else: ?>
            <div class="row gx-5 gy-5">
                <?php foreach ($mis_cursos as $curso): ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card h-100 shadow border-success border-2">
                            <img class="card-img-top" 
                                 src="/proyecto_cursos_mvc/public/assets/img/<?= htmlspecialchars($curso['imagen']) ?>" 
                                 alt="<?= htmlspecialchars($curso['titulo']) ?>">
                            
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title fw-bold text-success"><?= htmlspecialchars($curso['titulo']) ?></h5>
                                <p class="card-text text-muted small flex-grow-1">
                                    <?= substr(htmlspecialchars($curso['descripcion']), 0, 100) ?>...
                                </p>
                                
                                <div class="mt-auto">
                                   <a href="/proyecto_cursos_mvc/public/curso_material.php?id=<?= $curso['id'] ?>" class="btn btn-success rounded-pill w-100">
                                        <i class="fas fa-play-circle me-1"></i> Ir al Curso
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php 
include ROOT_PATH . "/app/views/partials/footer.php"; 
?>