<?php
// Reporte de errores y configuración de sesión
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('ROOT_PATH', dirname(__DIR__));
session_start();
require_once ROOT_PATH . "/app/config/database.php";

$db = new Database();
$conn = $db->getConnection();
$items_carrito = [];
$total_carrito = 0;

if ($conn === null) {
    $error_db = "No se pudo conectar a la base de datos.";
} else {
    
    // 1. Obtener la data del carrito (DB o Cookie)
    $ids_a_buscar = [];
    $cantidades = [];

    if (isset($_SESSION['usuario_id'])) {
        // Lógica para usuarios logueados (DB)
        $usuario_id = $_SESSION['usuario_id'];
        $query = "SELECT c.curso_id, c.cantidad, t.titulo, t.precio, t.imagen 
                  FROM carrito c 
                  JOIN cursos t ON c.curso_id = t.id 
                  WHERE c.usuario_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$usuario_id]);
        $items_carrito = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } else if (isset($_COOKIE['carrito'])) {
        // Lógica para visitantes (Cookie)
        $carrito_cookie = json_decode($_COOKIE['carrito'], true);
        
        if (!empty($carrito_cookie)) {
            $ids_a_buscar = array_keys($carrito_cookie);
            
            // Crear una lista de placeholders para la consulta (ej: ?, ?, ?)
            $placeholders = implode(',', array_fill(0, count($ids_a_buscar), '?'));
            
            // Obtener datos de cursos basándose en IDs de la cookie
            $query = "SELECT id, titulo, precio, imagen FROM cursos WHERE id IN ($placeholders)";
            $stmt = $conn->prepare($query);
            $stmt->execute($ids_a_buscar);
            $cursos_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Combinar la información de la cookie con los datos del curso
            foreach ($cursos_data as $curso) {
                $items_carrito[] = [
                    'curso_id' => $curso['id'],
                    'titulo' => $curso['titulo'],
                    'precio' => $curso['precio'],
                    'imagen' => $curso['imagen'],
                    'cantidad' => $carrito_cookie[$curso['id']]
                ];
            }
        }
    }

    // 2. Calcular el total
    foreach ($items_carrito as $item) {
        $total_carrito += $item['precio'] * $item['cantidad'];
    }
}

// Incluimos la vista del carrito
include ROOT_PATH . "/app/views/carrito.php";
?>