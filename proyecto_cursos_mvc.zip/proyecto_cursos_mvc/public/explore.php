<?php
// Reporte de errores
ini_set('display_errors', 1);
error_reporting(E_ALL);

define('ROOT_PATH', dirname(__DIR__));
session_start();
require_once ROOT_PATH . "/app/config/database.php";

$db = new Database();
$conn = $db->getConnection();
$cursos = [];
$error_message = "";

if ($conn) {
    // 1. Obtener todos los cursos
    $query = "SELECT id, titulo, descripcion, precio, imagen FROM cursos ORDER BY id ASC";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $error_message = "Error de conexión a la base de datos.";
}

$titulo = "Explorar Cursos";
include ROOT_PATH . "/app/views/partials/header.php";
?>

<section class="masthead">
    <div class="container px-5">
        <h1 class="display-4 text-center mb-5">Nuestro Catálogo de Cursos (<?= count($cursos) ?>)</h1>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger text-center"><?= htmlspecialchars($error_message) ?></div>
        <?php endif; ?>

        <div class="row gx-5 gy-5">
            <?php foreach ($cursos as $curso): ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100 shadow-sm border-0">
                        <img class="card-img-top" 
                             src="/proyecto_cursos_mvc/public/assets/img/<?= htmlspecialchars($curso['imagen']) ?>" 
                             alt="<?= htmlspecialchars($curso['titulo']) ?>">
                        
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title fw-bold text-primary"><?= htmlspecialchars($curso['titulo']) ?></h5>
                            <h4 class="text-success mb-3">$<?= number_format($curso['precio'], 2) ?></h4>
                            
                            <p class="card-text text-muted small flex-grow-1">
                                <?= substr(htmlspecialchars($curso['descripcion']), 0, 100) ?>...
                            </p>
                            
                            <div class="mt-auto d-flex justify-content-between">
                                <a href="/proyecto_cursos_mvc/public/detalles.php?id=<?= $curso['id'] ?>" class="btn btn-outline-primary btn-sm me-2">
                                    <i class="fas fa-eye me-1"></i> Ver Detalles
                                </a>
                                <form method="POST" action="/proyecto_cursos_mvc/public/carrito_add.php">
                                    <input type="hidden" name="curso_id" value="<?= $curso['id'] ?>">
                                    <button type="submit" class="btn btn-primary btn-sm">
                                        <i class="fas fa-cart-plus"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php 
include ROOT_PATH . "/app/views/partials/footer.php"; 
?>