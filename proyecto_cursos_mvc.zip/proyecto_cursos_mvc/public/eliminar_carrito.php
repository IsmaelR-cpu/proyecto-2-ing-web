<?php
session_start();
require_once "../app/config/database.php";

$db = new Database();
$conn = $db->getConnection();

if (!isset($_GET['id'])) {
    header("Location: ver_carrito.php");
    exit();
}

$id = $_GET['id'];

if (isset($_SESSION['usuario_id'])) {
    $stmt = $conn->prepare("DELETE FROM carrito WHERE usuario_id = ? AND curso_id = ?");
    $stmt->execute([$_SESSION['usuario_id'], $id]);
} else {
    $carrito = isset($_COOKIE['carrito']) ? json_decode($_COOKIE['carrito'], true) : [];
    unset($carrito[$id]);
    setcookie("carrito", json_encode($carrito), time() + (86400 * 7), "/");
}

header("Location: ver_carrito.php");
exit();
