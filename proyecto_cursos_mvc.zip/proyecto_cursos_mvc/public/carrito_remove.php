<?php
// Reporte de errores
ini_set('display_errors', 1);
error_reporting(E_ALL);

define('ROOT_PATH', dirname(__DIR__));
session_start();
require_once ROOT_PATH . "/app/config/database.php";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['curso_id'])) {
    
    $curso_id = filter_var($_POST['curso_id'], FILTER_VALIDATE_INT);
    if ($curso_id === false || $curso_id <= 0) {
        header("Location: carrito.php?error=ID_invalido");
        exit();
    }
    
    // 1. Lógica para USUARIOS LOGUEADOS (Base de Datos)
    if (isset($_SESSION['usuario_id'])) {
        $usuario_id = $_SESSION['usuario_id'];
        $db = new Database();
        $conn = $db->getConnection();

        if ($conn) {
            // Eliminar la fila del carrito
            $query_delete = "DELETE FROM carrito WHERE usuario_id = ? AND curso_id = ?";
            $stmt_delete = $conn->prepare($query_delete);
            $stmt_delete->execute([$usuario_id, $curso_id]);
        }
    } 
    // 2. Lógica para VISITANTES (Cookie)
    else {
        // Obtener el carrito de la cookie o iniciar uno vacío
        $carrito = isset($_COOKIE['carrito']) ? json_decode($_COOKIE['carrito'], true) : [];

        if (isset($carrito[$curso_id])) {
            // Eliminar el curso del array de la cookie
            unset($carrito[$curso_id]);
            
            // Reestablecer la cookie (o borrarla si queda vacía)
            if (!empty($carrito)) {
                setcookie('carrito', json_encode($carrito), time() + (86400 * 1), "/");
            } else {
                // Si el carrito está vacío, borrar la cookie
                setcookie('carrito', '', time() - 3600, "/");
            }
        }
    }

    // Redirigir a la página del carrito
    header("Location: carrito.php?removed=true");
    exit();
} 

// Redirigir si se accede directamente o sin ID
header("Location: carrito.php");
exit();
?>