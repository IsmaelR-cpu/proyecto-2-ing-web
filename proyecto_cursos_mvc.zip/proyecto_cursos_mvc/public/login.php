<?php
// Reporte de errores y configuración de sesión
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('ROOT_PATH', dirname(__DIR__));
// 🚨 ¡IMPORTANTE! INICIAR SESIÓN DEBE SER LA PRIMERA INSTRUCCIÓN
session_start(); 
require_once ROOT_PATH . "/app/config/database.php";

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $db = new Database();
    $conn = $db->getConnection();

    if ($conn) {
        // Buscar el usuario por email
        $query = "SELECT id, nombre, email, password FROM usuarios WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$email]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuario && password_verify($password, $usuario['password'])) {
            // -----------------------------------------------------------
            // ✅ CORRECCIÓN CLAVE: GUARDAR DATOS EN LA SESIÓN
            // -----------------------------------------------------------
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['nombre_usuario'] = $usuario['nombre']; // ¡Usamos 'nombre' para mostrar el saludo!
            // -----------------------------------------------------------
            
            // Redirigir a la página de inicio
            header("Location: /proyecto_cursos_mvc/public/index.php");
            exit();
        } else {
            $error_message = "Email o contraseña incorrectos.";
        }
    } else {
        $error_message = "Error de conexión a la base de datos.";
    }
}

// Incluimos la vista de login (con el error si lo hay)
include ROOT_PATH . "/app/views/auth/login.php";
?>