<?php
// Reporte de errores y configuración de sesión
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('ROOT_PATH', dirname(__DIR__));
session_start();
require_once ROOT_PATH . "/app/config/database.php";

$curso = null;
$error_message = "";

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $curso_id = $_GET['id'];
    
    $db = new Database();
    $conn = $db->getConnection();

    if ($conn) {
        // 🛑 CORRECCIÓN: Usamos 'titulo' y quitamos 'contenido'
        $query = "SELECT id, titulo, descripcion, imagen, precio FROM cursos WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$curso_id]);
        $curso = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$curso) {
            $error_message = "Curso no encontrado. El ID no es válido.";
        }
    } else {
        $error_message = "Error al conectar con la base de datos.";
    }
} else {
    $error_message = "ID de curso no especificado.";
}

// Incluimos la vista
include ROOT_PATH . "/app/views/detalles.php";
?>