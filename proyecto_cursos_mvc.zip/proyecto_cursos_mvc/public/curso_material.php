<?php
// Reporte de errores
ini_set('display_errors', 1);
error_reporting(E_ALL);

define('ROOT_PATH', dirname(__DIR__));
session_start();
require_once ROOT_PATH . "/app/config/database.php";

$db = new Database();
$conn = $db->getConnection();
$error_message = "";
$curso = null;

// 1. Redirigir si no está logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$curso_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

// 2. Verificar ID del curso
if (!$curso_id) {
    $error_message = "ID del curso no especificado o inválido.";
}

if ($curso_id && $conn) {
    try {
        // 3. Verificar si el usuario ha comprado este curso específico (Seguridad crítica)
        $query_check = "
            SELECT 
                c.id, c.titulo, c.descripcion, c.imagen, c.precio
            FROM 
                cursos c
            JOIN 
                pedido_detalle pd ON c.id = pd.curso_id
            JOIN 
                pedidos p ON pd.pedido_id = p.id
            WHERE 
                p.usuario_id = ? AND c.id = ?
            LIMIT 1
        ";
        
        $stmt_check = $conn->prepare($query_check);
        $stmt_check->execute([$usuario_id, $curso_id]);
        $curso = $stmt_check->fetch(PDO::FETCH_ASSOC);

        // Si el resultado es falso, el usuario no tiene permiso
        if (!$curso) {
            $error_message = "Acceso denegado: No has comprado este curso o el curso no existe.";
        }

    } catch (Exception $e) {
        $error_message = "Error de base de datos: " . $e->getMessage();
    }
} else if (!$conn) {
    $error_message = "Error de conexión a la base de datos.";
}

$titulo = $curso ? "Material: " . $curso['titulo'] : "Material del Curso";
include ROOT_PATH . "/app/views/partials/header.php";
?>

<section class="masthead">
    <div class="container px-5">
        
        <?php if ($error_message): ?>
            <div class="alert alert-danger text-center p-4 shadow">
                <h3 class="mb-3">¡Error de Acceso!</h3>
                <p class="lead"><?= htmlspecialchars($error_message) ?></p>
                <a href="/proyecto_cursos_mvc/public/mis_cursos.php" class="btn btn-warning btn-lg mt-3">Volver a Mis Cursos</a>
            </div>
        <?php else: ?>
            
            <h1 class="display-4 mb-4 text-center text-white"><?= htmlspecialchars($curso['titulo']) ?></h1>
            <h2 class="text-center text-light lead mb-5">¡Felicidades, tienes acceso ilimitado a este contenido!</h2>

            <div class="row gx-5">
                <div class="col-lg-9">
                    <div class="card shadow p-4">
                        <h3 class="border-bottom pb-3 mb-4 text-primary">Lección Actual: Introducción y Primeros Pasos</h3>
                        
                        <div class="ratio ratio-16x9 mb-4">
                            <iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1" title="Contenido del Curso" allowfullscreen></iframe>
                        </div>

                        <h4>Descripción del Módulo</h4>
                        <p class="text-muted"><?= htmlspecialchars($curso['descripcion']) ?></p>

                        <div class="mt-4">
                            <h5>Recursos Descargables</h5>
                            <a href="#" class="btn btn-outline-secondary me-2"><i class="fas fa-file-pdf"></i> PDF del Capítulo 1</a>
                            <a href="#" class="btn btn-outline-secondary"><i class="fas fa-code"></i> Código Fuente Base</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3">
                    <div class="card shadow p-3">
                        <h4 class="card-title border-bottom pb-2 mb-3">Módulos</h4>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item active">1. Introducción al Curso <i class="fas fa-play ms-2"></i></li>
                            <li class="list-group-item text-muted">2. Módulo Básico: Estructura</li>
                            <li class="list-group-item text-muted">3. Módulo Intermedio: Estilos</li>
                            <li class="list-group-item text-muted">4. Módulo Avanzado: Interacción</li>
                            <li class="list-group-item text-muted">5. Proyecto Final</li>
                        </ul>
                        <a href="/proyecto_cursos_mvc/public/mis_cursos.php" class="btn btn-link mt-3">← Volver a Mis Cursos</a>
                    </div>
                </div>

            </div>
        <?php endif; ?>
    </div>
</section>

<?php 
include ROOT_PATH . "/app/views/partials/footer.php"; 
?>